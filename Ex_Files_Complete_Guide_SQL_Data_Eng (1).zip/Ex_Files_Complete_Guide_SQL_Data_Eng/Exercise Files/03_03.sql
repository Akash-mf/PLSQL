select * from products

update products set price=500 where product_id =7

update products set price =700, category_id =2 where product_id =7